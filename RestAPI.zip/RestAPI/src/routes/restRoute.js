import {
    addDoctor, getDoctor, getDoctorByID, updateDoctorByID,  deleteDoctorByID,

    addUser, getUser, getUserByID,  updateUserByID, deleteUserByID,

    addMedicine, getMedicine, getMedicineByID,  updateMedicineByID, deleteMedicineByID,

    addLab, getLab, getLabByID,  updateLabByID, deleteLabByID,
} from '../controller/restController.js';


const allRoutes = (app) => {

    app.route('/doctor')
    .get(getDoctor)
    .post(addDoctor );

    app.route('/doctor/:doctorID')
    .get(getDoctorByID)
    .delete(deleteDoctorByID)
    .put(updateDoctorByID);

/*********************************************/

    app.route('/user')
    .get(getUser)
    .post(addUser );

    app.route('/user/:userID')
    .get(getUserByID)
    .delete(deleteUserByID)
    .put(updateUserByID);

/*********************************************/

    app.route('/medicine')
    .get(getMedicine)
    .post(addMedicine );

    app.route('/medicine/:medicineID')
    .get(getMedicineByID)
    .delete(deleteMedicineByID)
    .put(updateMedicineByID);

/*********************************************/

    app.route('/lab')
    .get(getLab)
    .post(addLab );

    app.route('/lab/:labID')
    .get(getLabByID)
    .delete(deleteLabByID)
    .put(updateLabByID);
}

export default allRoutes;