
import mongoose from 'mongoose';
LabSchema
import { DoctorSchema } from '../model/restModel.js';
import { UserSchema } from '../model/restModel.js';
import { MedicineSchema } from '../model/restModel.js';
import { LabSchema } from '../model/restModel.js';


const Doctor = mongoose.model('Doctor', DoctorSchema);
const User = mongoose.model('User', UserSchema);
const Medicine = mongoose.model('Medicine', MedicineSchema);
const Lab = mongoose.model('Lab', LabSchema);

/**************DOCTOR CONTROLLER********************************** */
export const addDoctor = (req, res) => {

    let newDoctor = new Doctor(req.body);
    newDoctor.save((err, doctor) => {
        if (err) {
            res.send(err);
        }
        res.json(doctor)
    });

}
export const getDoctor = (req, res) => {

    Doctor.find({}, (err, doctor) => {
        if (err) {
            res.send(err);
        }
        res.json(doctor);
    });

}
export const getDoctorByID = (req, res) => {   

    Doctor.findById(req.params.doctorID, (err, doctor) => {
        if (err) {
            res.send(err);
        }
        res.json(doctor);
    });

}
export const updateDoctorByID = (req, res) => {

    Doctor.findOneAndUpdate({ _id: req.params.doctorID },
        req.body,
        { new: true },
        (err, doctor) => {
            if (err) {
                res.send(err);
            }
            res.json(doctor);
        });

}
export const deleteDoctorByID = (req, res) => {
    Doctor.remove({ _id: req.params.doctorID },
        (err, doctor) => {
            if (err) {
                res.send(err);
            }
            res.json({ message: "The doctor was deleted." });
        });

}

/**************USER CONTROLLER********************************** */


export const addUser = (req, res) => {

    let newUser = new User(req.body);
    newUser.save((err, user) => {
        if (err) {
            res.send(err);
        }
        res.json(user)
    });

}
export const getUser = (req, res) => {

    User.find({}, (err, user) => {
        if (err) {
            res.send(err);
        }
        res.json(user);
    });

}
export const getUserByID = (req, res) => {   

    User.findById(req.params.userID, (err, user) => {
        if (err) {
            res.send(err);
        }
        res.json(user);
    });

}
export const updateUserByID = (req, res) => {

    User.findOneAndUpdate({ _id: req.params.userID },
        req.body,
        { new: true },
        (err, user) => {
            if (err) {
                res.send(err);
            }
            res.json(user);
        });

}
export const deleteUserByID = (req, res) => {
    User.remove({ _id: req.params.userID },
        (err, user) => {
            if (err) {
                res.send(err);
            }
            res.json({ message: "The doctor was deleted." });
        });

}


/**************MEDICINE CONTROLLER********************************** */


export const addMedicine = (req, res) => {

    let newMedicine = new Medicine(req.body);
    newMedicine.save((err, medicine) => {
        if (err) {
            res.send(err);
        }
        res.json(medicine)
    });

}
export const getMedicine = (req, res) => {

    Medicine.find({}, (err, medicine) => {
        if (err) {
            res.send(err);
        }
        res.json(medicine);
    });

}
export const getMedicineByID = (req, res) => {   

    Medicine.findById(req.params.medicineID, (err, medicine) => {
        if (err) {
            res.send(err);
        }
        res.json(medicine);
    });

}
export const updateMedicineByID = (req, res) => {

    Medicine.findOneAndUpdate({ _id: req.params.medicineID },
        req.body,
        { new: true },
        (err, medicine) => {
            if (err) {
                res.send(err);
            }
            res.json(medicine);
        });

}
export const deleteMedicineByID = (req, res) => {
    Medicine.remove({ _id: req.params.medicineID },
        (err, medicine) => {
            if (err) {
                res.send(err);
            }
            res.json({ message: "The medicine was deleted." });
        });

}

/****************LAB CONTROLLER************************************** */


export const addLab = (req, res) => {

    let newLab = new Lab(req.body);
    newLab.save((err, lab) => {
        if (err) {
            res.send(err);
        }
        res.json(lab)
    });

}
export const getLab = (req, res) => {

    Lab.find({}, (err, lab) => {
        if (err) {
            res.send(err);
        }
        res.json(lab);
    });

}
export const getLabByID = (req, res) => {   

    Lab.findById(req.params.labID, (err, lab) => {
        if (err) {
            res.send(err);
        }
        res.json(lab);
    });

}
export const updateLabByID = (req, res) => {

    Lab.findOneAndUpdate({ _id: req.params.labID },
        req.body,
        { new: true },
        (err, lab) => {
            if (err) {
                res.send(err);
            }
            res.json(lab);
        });

}
export const deleteLabByID = (req, res) => {
    Lab.remove({ _id: req.params.labID },
        (err, lab) => {
            if (err) {
                res.send(err);
            }
            res.json({ message: "The Labtest was deleted." });
        });

}