//import mongoose
import mongoose from 'mongoose';


const schema = mongoose.Schema;


export const DoctorSchema = new schema({

    name: {
        type: String,
        required: 'Please enter a name.'
    },
    rating : {
        type: String,
    },
    category: {
        type: String,
    },
    year_experience: {
        type: Number,
        required: 'Please enter a year.'
    },
    area: {
        type: String,
    },
    description:{
        type:String
    },
    creation_date: {
        type: Date,
        default: Date.now
    }
});

/****************USER SCHEMA****************** */

export const UserSchema = new schema({

    name: {
        type: String,
        required: 'Please enter a name.'
    },
    email: {
        type: String,
        required: 'PLease enter email'
    },
    password: {
        type: String,
        required: 'Please enter password'
    },
    cnf_password: {
        type: String,
        required: 'Please enter password'
    },
    isAdmin: {
        type: Boolean,
        required: false
    },
    creation_date: {
        type: Date,
        default: Date.now
    }
});

/****************MEDICINE SCHEMA****************** */

export const MedicineSchema = new schema({

    name: {
        type: String,
        required: 'Please enter a name.'
    },
    type : {
        type: String,
    },
    onPrescription:{
        type :Boolean,
        default: false
    },
    category: {
        type: String,
    },
    price: {
        type: Number,
    },
    description:{
        type:String
    }
});

/****************LABTEST SCHEMA****************** */

export const LabSchema = new schema({

    name: {
        type: String,
        required: 'Please enter a name.'
    },
    type : {
        type: String,
    },
    lab:{
        type :String,
        default: "Dr Pathlabs"
    },
    home_service: {
        type: Boolean,
        default: false
    },
    price: {
        type: Number,
    },
    description:{
        type:String
    },
    result_time:{
        type :String,
    },
});

