
import express from 'express';
import allRoutes from './src/routes/restRoute.js';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';

//const http = require('http')
const app = express();
const port =  4000;
// const server =http.createServer(app)

const URI = "mongodb+srv://aryan:aryan@cluster0.fm09mwa.mongodb.net/DoctorApp?retryWrites=true&w=majority"

mongoose.Promise = global.Promise;
mongoose.set('strictQuery',true)
mongoose.connect(URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

allRoutes(app);

app.get('/', (req, res) =>
    res.send(`Your node and express server is running on port: ${port}`)
);

app.listen(port, () => {
    console.log("restAPI is running on port: " + port);
});